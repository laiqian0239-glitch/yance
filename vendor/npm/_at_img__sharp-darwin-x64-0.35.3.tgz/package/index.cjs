try { require.resolve('@img/sharp-libvips-darwin-x64/binary'); } catch {}
module.exports = require('./lib/sharp-darwin-x64-0.35.3.node');