try { require.resolve('@img/sharp-libvips-linux-riscv64/binary'); } catch {}
module.exports = require('./lib/sharp-linux-riscv64-0.35.3.node');