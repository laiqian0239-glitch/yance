try { require.resolve('@img/sharp-libvips-linux-s390x/binary'); } catch {}
module.exports = require('./lib/sharp-linux-s390x-0.35.3.node');