try { require.resolve('@img/sharp-libvips-linux-ppc64/binary'); } catch {}
module.exports = require('./lib/sharp-linux-ppc64-0.35.3.node');