try { require.resolve('@img/sharp-libvips-linux-arm/binary'); } catch {}
module.exports = require('./lib/sharp-linux-arm-0.35.3.node');